
const express = require("express");

const app = express();
const PORT = 3000;

app.use(express.json());

const conteudos = [
  {
    id: 1,
    titulo: "Introdução à Ecologia",
    disciplina: "Biologia",
    resumo:
      "Ecologia estuda as relações dos seres vivos entre si e com o ambiente."
  },
  {
    id: 2,
    titulo: "Introdução à Trigonometria",
    disciplina: "Matemática",
    resumo:
      "Trigonometria estuda as relações entre ângulos e lados dos triângulos."
  }
];

app.get("/", (req, res) => {
  res.json({
    mensagem: "API do Aprendi AI funcionando!",
    status: "online"
  });
});

app.get("/api/conteudos", (req, res) => {
  res.json(conteudos);
});

app.listen(PORT, () => {
  console.log(`API rodando em http://localhost:${PORT}`);
});
